<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="card shadow">
        <div class="card-header py-3">
            <h class="m-0 font-weight-bold text-primary"><?=$title?></h>
        </div>
        <div class="card-body">
            <div class="box_general padding_bottom">
                <div class="accordion" id="accordionExample">
                    <div class="card">
                        <div class="card-header" id="headingOne">
                            <h2 class="mb-0">
                                <button class="btn btn-link btn-block text-left" type="button"data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    API Lihat Data Vaksin
                                </button>
                            </h2>
                        </div>

                        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                            <div class="card-body">
                                <p>API data Vaksin dapat dilihat pada link berikut : <a href="<?=site_url('api-vaksin')?>">Lihat Data Vaksin</a></p>
                                Hasil jika memakai postman :
                                <img src="<?=base_url('assets/assets_admin/api/lihat-data.png')?>" alt="Icon" class="img-fluid mb-3">
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="headingOne">
                            <h2 class="mb-0">
                                <button class="btn btn-link btn-block text-left collapsed" type="button"data-toggle="collapse" data-target="#collapseOned" aria-expanded="true" aria-controls="collapseOned">
                                    API Lihat Data Vaksin Berdasarkan ID Vaksin
                                </button>
                            </h2>
                        </div>

                        <div id="collapseOned" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                            <div class="card-body">
                                <p>API data Vaksin berdasarkan ID Vaksin dapat dilihat pada link berikut : <a href="<?=site_url('api-vaksin/1')?>">Lihat Data Vaksin By ID Vaksin</a></p>
                                Hasil jika memakai postman :
                                <img src="<?=base_url('assets/assets_admin/api/lihat-data-by-id.png')?>" alt="Icon" class="img-fluid mb-3">
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="headingTwo">
                            <h2 class="mb-0">
                                <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    API Tambah Data Vaksin
                                </button>
                            </h2>
                        </div>
                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                            <div class="card-body">
                                <p>API tambah data Vaksin dapat dilihat pada link berikut : <a href="<?=site_url('api-vaksin/add')?>">Tambah Data Vaksin</a></p>
                                Hasil jika memakai postman :
                                <img src="<?=base_url('assets/assets_admin/api/tambah-data.png')?>" alt="Icon" class="img-fluid mb-3">
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="headingThree">
                            <h2 class="mb-0">
                                <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    API Update Data Vaksin
                                </button>
                            </h2>
                        </div>
                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                            <div class="card-body">
                                <p>API update data Vaksin dapat dilihat pada link berikut : <a href="<?=site_url('api-vaksin/update')?>">Update Data Vaksin</a></p>
                                Hasil jika memakai postman :
                                <img src="<?=base_url('assets/assets_admin/api/update-data.png')?>" alt="Icon" class="img-fluid mb-3">
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="headingThree">
                            <h2 class="mb-0">
                                <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                    API Hapus Data Vaksin
                                </button>
                            </h2>
                        </div>
                        <div id="collapseFour" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                            <div class="card-body">
                                <p>API hapus data Vaksin dapat dilihat pada link berikut : <a href="<?=site_url('api-vaksin/delete')?>">Hapus Data Vaksin</a></p>
                                Hasil jika memakai postman :
                                <img src="<?=base_url('assets/assets_admin/api/delete-data.png')?>" alt="Icon" class="img-fluid mb-3">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->