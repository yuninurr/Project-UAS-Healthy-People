<!-- Begin Page Content -->
<div class="container-fluid">
    <?= $this->session->flashdata('pesan'); ?>
    <div class="card shadow">
        <div class="card-header py-3">
            <h class="m-0 font-weight-bold text-primary">Import Data Vaksin</h>
            <a href="<?= base_url('data_vaksin') ?>" class="btn btn-primary waves-effect btn-sm float-right ml-3">Kembali</a>
        </div>
        <div class="card-body">
            <form action="<?=site_url('data_vaksin/import/data')?>" method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label>File Excel <small class="text-danger">(Format : csv/xlsx, Max. 3mb)</small></label>
                    <input class="form-control" type="file" name="upload_file" required>
                    <small class="text-danger"><?=form_error('upload_file') ?></small>
                </div>
                <a href="<?=site_url('data_vaksin/import/format')?>" class="btn btn-sm btn-danger" target="_blank">Download Format Import</a>
                <button type="submit" class="btn btn-primary btn-sm">Import</button>
            </form>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->