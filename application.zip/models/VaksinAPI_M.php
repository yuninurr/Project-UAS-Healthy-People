<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class VaksinAPI_M extends CI_Model
{

	public function all_vaksin(){
		$all = $this->db->select('*')->from('vaksin')->order_by('id_vaksin','DESC')->get()->result();
		$response['status'] = 200;
		$response['error'] = false;
		$response['vaksin'] = $all;
		return $response;
	}

	public function empty_response()
	{
		$response['status'] = 502;
		$response['error'] = true;
		$response['message'] = 'Field tidak boleh kosong';

		return $response;
	}

	public function add_vaksin($kode_type,$nama,$jumlah,$status)
	{
		if(empty($kode_type) || empty($nama) || empty($jumlah) || empty($status)){
			return $this->empty_response();
		} else {
			$data = array(
				"kode_type" => $kode_type,
				"nama" => $nama,
				"jumlah" => $jumlah,
				"status" => $status,
			);

			$insert = $this->db->insert("vaksin", $data);

			if($insert){
				$response['status'] = 200;
				$response['error'] = false;
				$response['message'] = 'Data vaksin ditambahkan.';
				
				return $response;

			} else {
				$response['status'] = 502;
				$response['error'] = true;
				$response['message'] = 'Data vaksin gagal ditambahkan.';
				
				return $response;
			}
		}
	}

	public function delete_vaksin($id_vaksin)
	{
		if($id_vaksin == ''){
			return $this->empty_response();
		} else {
			$where = array(
				"id_vaksin" => $id_vaksin
			);
			$this->db->where($where);
			$delete = $this->db->delete("vaksin");

			if($delete){
				$response['status'] = 200;
				$response['error'] = false;
				$response['message'] = 'Data vaksin dihapus.';

				return $response;
			} else {
				$response['status'] = 502;
				$response['error'] = true;
				$response['message'] = 'Data vaksin gagal dihapus.';

				return $response;
			}
		}
	}

	public function update_vaksin($id_vaksin,$kode_type,$nama,$jumlah,$status)
	{
		if($id_vaksin == '' || empty($kode_type) || empty($nama) || empty($jumlah) || empty($status)){
			return $this->empty_response();
		} else {
			$where = array(
				"id_vaksin" => $id_vaksin
			);

			$set = array(
				"kode_type" => $kode_type,
				"nama" => $nama,
				"jumlah" => $jumlah,
				"status" => $status,
			);
			$this->db->where($where);
			$update = $this->db->update("vaksin",$set);

			if($update){
				$response['status'] = 200;
				$response['error'] = false;
				$response['message'] = 'Data vaksin diubah.';

				return $response;
			}else{
				$response['status'] = 502;
				$response['error'] = true;
				$response['message'] = 'Data vaksin gagal diubah.';

				return $response;
			}
		}
	}

}