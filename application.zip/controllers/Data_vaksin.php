<?php
defined('BASEPATH') or exit('No direct script access allowed');

// require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Data_vaksin extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Vaksin_model');
        $this->load->library('upload');
        if ($this->session->userdata('email') == NULL) {
            redirect('login');
        }
    }

    public function index()
    {

        $data['vaksin'] = $this->Vaksin_model->get_data('vaksin')->result();
        $data['type'] = $this->Vaksin_model->get_data('type')->result();

        $this->load->view('templates_admin/admin_header');
        $this->load->view('templates_admin/admin_sidebar');
        $this->load->view('templates_admin/admin_topbar', $data);
        $this->load->view('admin/data_vaksin', $data);
        $this->load->view('templates_admin/admin_footer');
    }

    public function destroy_datavaksin($id)
    {
        $where = array('id_vaksin' => $id);
        $this->Vaksin_model->destroy_vaksin($where, 'vaksin');
        $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong>Success!</strong> Removed successfull </div>');
        redirect('data_vaksin');
    }

    public function tambah_vaksin()
    {
        $data['vaksin'] = $this->Vaksin_model->get_data('vaksin')->result();
        $data['type'] = $this->Vaksin_model->get_data('type')->result();
        $this->load->view('templates_admin/admin_header');
        $this->load->view('templates_admin/admin_sidebar');
        $this->load->view('templates_admin/admin_topbar', $data);
        $this->load->view('admin/data_vaksin', $data);
        $this->load->view('templates_admin/admin_footer');
    }

    public function detail_vaksin($id)
    {
        $data['vaksin'] = $this->Vaksin_model->ambil_id_vaksin($id);
        $data['type'] = $this->Vaksin_model->get_data('type')->result();
        $this->load->view('templates_admin/admin_header');
        $this->load->view('templates_admin/admin_sidebar');
        $this->load->view('templates_admin/admin_topbar');
        $this->load->view('admin/data_vaksin', $data);
        $this->load->view('templates_admin/admin_footer');
    }

    public function tambah_vaksin_aksi()
    {
        $this->_rules();
        if ($this->form_validation->run() == FALSE) {
            $this->tambah_vaksin();
        } else {
            $kode_type          = $this->input->post('kode_type');
            $nama               = $this->input->post('nama');
            $jumlah             = $this->input->post('jumlah');
            $status             = $this->input->post('status');

            $data = array(
                'kode_type'         => $kode_type,
                'nama'              => $nama,
                'jumlah'            => $jumlah,
                'status'            => $status,
            );

            $this->Vaksin_model->insert_data($data, 'vaksin');
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>Success!</strong> Berhasil</div>');
            redirect('data_vaksin');
        }
    }

    public function update_vaksin_aksi()
    {
        $this->_rules();

        $data['vaksin'] = $this->Vaksin_model->get_data('vaksin')->result();
        $data['type'] = $this->Vaksin_model->get_data('type')->result();

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates_admin/admin_header');
            $this->load->view('templates_admin/admin_sidebar');
            $this->load->view('templates_admin/admin_topbar');
            $this->load->view('admin/data_vaksin', $data);
            $this->load->view('templates_admin/admin_footer');
        } else {
            $id                 = $this->input->post('id_vaksin');
            $kode_type          = $this->input->post('kode_type');
            $nama               = $this->input->post('nama');
            $jumlah             = $this->input->post('jumlah');
            $status             = $this->input->post('status');

            $data = array(
                'kode_type'         => $kode_type,
                'nama'              => $nama,
                'jumlah'            => $jumlah,
                'status'            => $status,
            );

            $where = array(
                'id_vaksin' => $id
            );

            $this->Vaksin_model->update_data('vaksin', $data, $where);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>Success!</strong> Satuan Kerja Changed</div>');
            redirect('data_vaksin');
        }
    }

    public function _rules()
    {
        $this->form_validation->set_rules('kode_type', 'Kode Vaksin', 'trim|required');
        $this->form_validation->set_rules('nama', 'Nama', 'trim|required');
        $this->form_validation->set_rules('jumlah', 'Jumlah', 'trim|required|numeric');
        $this->form_validation->set_rules('status', 'Status', 'trim|required');
    }
    public function chart()
    {

        $data['vaksin'] = $this->Vaksin_model->get_data('vaksin')->result();
        $data['type'] = $this->Vaksin_model->get_data('type')->result();

        $this->load->view('templates_admin/admin_header');
        $this->load->view('templates_admin/admin_sidebar');
        $this->load->view('templates_admin/admin_topbar', $data);
        $this->load->view('admin/chart', $data);
        $this->load->view('templates_admin/admin_footer');
    }
    public function expdf()
    {
        require './assets/vendor/autoload.php';
        $mpdf = new \Mpdf\Mpdf();
        $datavaksin = $this->Vaksin_model->getAllVaksin();
        $data = $this->load->view('pdf/mpdf', ['semuavaksin' => $datavaksin], TRUE);
        $mpdf->WriteHTML($data);
        $mpdf->Output();
    }

    public function exexcel()
    {
        $data['vaksin'] = $this->Vaksin_model->getAllVaksin();
        $this->load->view('admin/exel', $data);
    }

    public function view_import_data_vaksin()
    {
        $data['title'] = "Import Data Vaksin";

        $this->load->view('templates_admin/admin_header');
        $this->load->view('templates_admin/admin_sidebar');
        $this->load->view('templates_admin/admin_topbar', $data);
        $this->load->view('admin/import_data_vaksin');
        $this->load->view('templates_admin/admin_footer');
    }

    public function download_format_import_vaksin()
    {
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="format_import_vaksin.xlsx"');

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', 'Kode Type');
        $sheet->setCellValue('B1', 'Nama Vaksin');
        $sheet->setCellValue('C1', 'Jumlah');
        $sheet->setCellValue('D1', 'Status (0 = Tidak tersedia dan 1 = Tersedia)');

        $writer = new Xlsx($spreadsheet);
        $writer->save("php://output");
    }

    public function import_data_vaksin()
    {
        $upload_file = $_FILES['upload_file']['name'];
        $extension = pathinfo($upload_file, PATHINFO_EXTENSION);

        if (empty($_FILES['upload_file']['name'])) {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>Error!</strong> Data import kosong!</div>');
            redirect('data_vaksin/import');
        } else if($extension != 'csv' && $extension != 'xls' && $extension != 'xlsx' && $extension != 'CSV' && $extension != 'XLS' && $extension != 'XLSX') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>Error!</strong> Format file tidak didukung!</div>');
            redirect('data_vaksin/import');
        } else {
            if ($extension == 'csv') {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
            } else if($extension == 'xls') {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
            } else {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            }

            $spreadsheet = $reader->load($_FILES['upload_file']['tmp_name']);
            $sheetdata = $spreadsheet->getActiveSheet()->toArray();

            $sheetcount = count($sheetdata);
            if ($sheetcount > 0) {
                for ($i=1; $i < $sheetcount; $i++) { 
                    $kode_type = $sheetdata[$i][0];
                    $nama = $sheetdata[$i][1];
                    $jumlah = $sheetdata[$i][2];
                    $status = $sheetdata[$i][2];

                    $data[] = array(
                        'kode_type' => $kode_type,
                        'nama' => $nama,
                        'jumlah' => $jumlah,
                        'status' => $status,
                    );
                }
                $this->Vaksin_model->import_data_vaksin($data);

                if ($this->db->affected_rows() > 0) {
                    $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <strong>Success!</strong> Berhasil mengimport data!</div>');
                    redirect('data_vaksin');
                } else {
                    $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <strong>Error!</strong> Gagal mengimport data!</div>');
                    redirect('data_vaksin/import');
                }
            }
        }
    }

    public function export_data_vaksin()
    {
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="data_vaksin.xlsx"');

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', 'No.');
        $sheet->setCellValue('B1', 'Kode Type');
        $sheet->setCellValue('C1', 'Nama Vaksin');
        $sheet->setCellValue('D1', 'Jumlah');
        $sheet->setCellValue('E1', 'Status (0 = Tidak tersedia dan 1 = Tersedia)');

        $listdata = $this->Vaksin_model->data_vaksin()->result();
        $list = 2;
        $no = 1;
        foreach ($listdata as $data) {
            $sheet->setCellValue('A'.$list,$no++);
            $sheet->setCellValue('B'.$list,$data->kode_type);
            $sheet->setCellValue('C'.$list,$data->nama);
            $sheet->setCellValue('D'.$list,$data->jumlah);
            $sheet->setCellValue('E'.$list,$data->status);
            $list++;
        }

        $writer = new Xlsx($spreadsheet);
        $writer->save("php://output");
    }

    public function export_pdf_vaksin()
    {
        $this->load->library('pdfgenerator');
        
        $data['title'] = 'Data Vaksin';
        $data['vaksin'] = $this->Vaksin_model->data_vaksin()->result();
        
        $file_pdf = 'data_vaksin';
        $paper = 'A4';
        $orientation = "landscape";
        
        $html = $this->load->view('admin/laporan_vaksin', $data, true);       
        
        $this->pdfgenerator->generate($html, $file_pdf, $paper, $orientation);
    }
}
