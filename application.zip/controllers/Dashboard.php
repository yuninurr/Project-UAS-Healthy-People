<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('email') == NULL) {
            redirect('login');
        }
    }

    public function index()
    {
        $this->load->view('templates_admin/admin_header');
        $this->load->view('templates_admin/admin_sidebar');
        $this->load->view('templates_admin/admin_topbar');
        $this->load->view('admin/dashboard');
        $this->load->view('templates_admin/admin_footer');
    }

    public function api_vaksin()
    {
        $data['title'] = "API Data Vaksin";

        $this->load->view('templates_admin/admin_header');
        $this->load->view('templates_admin/admin_sidebar');
        $this->load->view('templates_admin/admin_topbar', $data);
        $this->load->view('admin/api_data_vaksin');
        $this->load->view('templates_admin/admin_footer');
    }
}
