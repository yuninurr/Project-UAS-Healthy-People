<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use chriskacerguis\RestServer\RestController;

class VaksinAPIController extends RestController {

	function __construct()
	{
		parent::__construct();
		$this->load->library('upload');
		$this->load->model('VaksinAPI_M');
		// if ($this->session->userdata('email') == NULL) {
		// 	redirect('login');
		// }
	}

	public function index_get()
	{
		$response = $this->VaksinAPI_M->all_vaksin();

		$this->response($response);
	}

	public function vaksin_get($id)
	{
		$all = $this->db->select('*')->from('vaksin')->order_by('id_vaksin','DESC')->where('id_vaksin', $id)->get()->row_array();
		$response['status'] = 200;
		$response['error'] = false;
		$response['vaksin'] = $all;

		$this->response($response);
	}

	public function addvaksin_post()
	{
		$response = $this->VaksinAPI_M->add_vaksin(
			$this->post('kode_type'),
			$this->post('nama'),
			$this->post('jumlah'),
			$this->post('status'),
		);

		$this->response($response);
	}

	public function deletevaksin_delete()
	{
		$response = $this->VaksinAPI_M->delete_vaksin(
			$this->delete('id_vaksin')
		);

		$this->response($response);
	}

	public function updatevaksin_put()
	{
		$response = $this->VaksinAPI_M->update_vaksin(
			$this->put('id_vaksin'),
			$this->put('kode_type'),
			$this->put('nama'),
			$this->put('jumlah'),
			$this->put('status'),
		);

		$this->response($response);
	}

}
